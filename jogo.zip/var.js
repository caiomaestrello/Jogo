var Jogador1;
var Jogador2;


function Escolha1(){

    Jogador1 = "1";
}

function Escolha2(){

    Jogador1 = "2";
}
function Escolha3(){

    Jogador1 = "3";
}

function Escolha1(){

    Jogador2 = "4";
}
function Escolha2(){

    Jogador2 = "5"; 
}

function Escolha3(){

    Jogador2 = "6";
}
